/* eslint no-new:off */
import * as Utils from 'uptoo-react-utils';
import AuthConstants from './constants';

console.log('UTILS', Utils);

const AuthActionsInstance = class AuthActions extends AuthConstants {
    constructor(UtilsClass) {
        super();

        this.Config = UtilsClass.Config;
        this.Storage = UtilsClass.Cookies || UtilsClass.Storage;
        this.Requester = UtilsClass.Requester;
    }

    login = ({email, password}) => dispatch => {
        console.log('AUTH ACTION CLASS', this);
        dispatch({type: this.LOGIN_LOADING});
        this.Requester.post(`${this.Config.get('API_DOMAIN')}/login`, {email, password}).then(resp => {
            if (resp.authenticator) {
                dispatch({
                    type: this.AUTH_AUTHENTICATOR,
                    payload: resp.authenticator
                });
            }
            return null;
        }, err => {
            dispatch({
                type: this.LOGIN_ERROR,
                payload: err.message
            });
        });
    };

    authenticate = ({authenticator, digicode}) => dispatch => {
        dispatch({type: this.LOGIN_LOADING});

        this.Requester.post(`${this.Config.get('API_DOMAIN')}/authenticate`, {authenticator, digicode}).then(() => {}, err => {
            dispatch({
                type: this.LOGIN_ERROR,
                payload: err.message
            });
        });
    };

    restore = token => dispatch => {
        console.log('this.AUTH_TOKEN', this.AUTH_TOKEN)
        dispatch({
            type: this.AUTH_TOKEN,
            payload: token
        });
    };

    logout = () => dispatch => {
        this.Storage.delete(this.Config.get('JWT_TOKEN'));
        dispatch({type: this.LOGOUT});
    };

    register = ({firstName, lastName, email, password, confirmPassword}) => dispatch => {
        dispatch({type: this.REGISTER_LOADING});

        this.Requester.post(`${this.Config.get('API_DOMAIN')}/register`, {firstName, lastName, email, password, confirmPassword}).then(resp => {
            dispatch({
                type: this.REGISTER_DATA,
                payload: resp
            });
        }, err => {
            dispatch({
                type: this.REGISTER_ERROR,
                payload: err.message
            });
        });
    };

    forgot = email => dispatch => {
        dispatch({type: this.FORGOT_PASSWORD_LOADING});

        this.Requester.post(`${this.Config.get('API_DOMAIN')}/password/forgot`, {email}).then(resp => {
            dispatch({
                type: this.FORGOT_PASSWORD_DATA,
                payload: resp
            });
        }, err => {
            dispatch({
                type: this.FORGOT_PASSWORD_ERROR,
                payload: err.message
            });
        });
    };

    reset = (token, password, confirmPassword) => dispatch => {
        dispatch({type: this.RESET_PASSWORD_LOADING});

        this.Requester.post(`${this.Config.get('API_DOMAIN')}/password/reset`, {token, password, confirmPassword}).then(resp => {
            dispatch({
                type: this.RESET_PASSWORD_DATA,
                payload: resp
            });
        }, err => {
            dispatch({
                type: this.RESET_PASSWORD_ERROR,
                payload: err.message
            });
        });
    };
};

let instance = null;

function getInstance() {
    /**
     * Singelton (Une seul instance de classe)
     *
     * Instanciated with the default storage manager
     */
    if (!instance)
        instance = new AuthActionsInstance(Utils);
    return instance;
}

export default {
    Instance: AuthActionsInstance,
    login: getInstance().login,
    restore: getInstance().restore,
    logout: getInstance().logout,
    register: getInstance().register,
    authenticate: getInstance().authenticate,
    forgot: getInstance().forgot,
    reset: getInstance().reset
};
