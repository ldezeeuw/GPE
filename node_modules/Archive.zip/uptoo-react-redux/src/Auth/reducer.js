import Constants from './constants';
import TplConst from './../Template/constants';

let user;
let winAtob;
const Const = new Constants();
const {RESET_ERRORS} = new TplConst();
const initialState = {
    user: null,
    error: null,
    loading: false,
    authenticator: null,
    resetPasswordToken: null
};

export default function reduce(state = initialState, {type, payload}) {
    switch (type) {
        case RESET_ERRORS:
            return {...state, error: null};

        case Const.LOGIN_LOADING:
            return {...state, loading: true, error: null};

        case Const.LOGIN_ERROR:
            return {...state, loading: false, error: payload};

        case Const.AUTH_TOKEN:
            user = payload.split('.')[1];
            user = user.replace('-', '+').replace('_', '/');
            winAtob = window && window.atob ? window.atob : require('base-64').decode;
            user = JSON.parse(decodeURIComponent(escape(winAtob(user))));
            return {...state, user, loading: false, error: null};

        case Const.AUTH_AUTHENTICATOR:
            return {...state, authenticator: payload, loading: false, error: null};

        case Const.LOGOUT:
            return initialState;

        case Const.REGISTER_LOADING:
            return {...state, loading: true, error: null};

        case Const.REGISTER_ERROR:
            return {...state, error: payload, loading: false};

        case Const.REGISTER_DATA:
            return {...state, loading: false, error: null};

        case Const.FORGOT_PASSWORD_LOADING:
            return {...state, loading: true, error: null, resetPasswordToken: null};

        case Const.FORGOT_PASSWORD_ERROR:
            return {...state, error: payload, loading: false, resetPasswordToken: null};

        case Const.FORGOT_PASSWORD_DATA:
            return {...state, loading: false, error: null, resetPasswordToken: payload};

        case Const.RESET_PASSWORD_LOADING:
            return {...state, loading: true, error: null};

        case Const.RESET_PASSWORD_ERROR:
            return {...state, error: payload, loading: false};

        case Const.RESET_PASSWORD_DATA:
            return {...state, loading: false, error: null};

        default:
            return state;
    }
}
