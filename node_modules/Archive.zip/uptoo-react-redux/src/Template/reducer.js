import Const from './constants';

const Consts = new Const();

const {
    ROUTES_INIT,
    WINDOW_RESIZE,
    SIDEBAR_TOGGLE,
    SIDEBAR_SET_VISIBLE,
    TOASTR,
    REDIRECT,
    REDIRECT_RESET,
    // UNAUTHORIZED
} = Consts;

const initialState = {
    routes: {
        config: [],
        navbar: [],
        sidebar: []
    },
    size: {
        device: '',
        width: 0
    },
    sidebar: {isVisible: false},
    toastr: {
        type: null,
        content: '',
        time: null,
        onClick: null
    },
    navigation: {
        redirect: null,
        unauthorized: false
    }
};

export default function reduce(state = initialState, {type, payload}) {
    switch (type) {
        case ROUTES_INIT:
            return {...state, routes: payload};

        case WINDOW_RESIZE:
            return {...state, size: payload};

        case SIDEBAR_TOGGLE:
            return {...state, sidebar: {isVisible: !state.sidebar.isVisible}};

        case SIDEBAR_SET_VISIBLE:
            return {...state, sidebar: {isVisible: payload}};

        case TOASTR:
            return {...state, toastr: {...payload}};

        case REDIRECT:
            return {...state, navigation: {redirect: payload}};

        case REDIRECT_RESET:
            return {...state, navigation: {redirect: null}};

        default:
            return state;
    }
}
