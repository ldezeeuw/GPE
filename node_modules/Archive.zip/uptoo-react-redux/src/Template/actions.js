import Const from './constants';

const Consts = new Const();

const {
    ROUTES_INIT,
    WINDOW_RESIZE,
    SIDEBAR_TOGGLE,
    SIDEBAR_SET_VISIBLE,
    RESET_ERRORS,
    TOASTR,
    REDIRECT_RESET
} = Consts;

const getRoutes = (routes, finalRoutes = []) => {
    if (Array.isArray(routes) && routes.length > 0) {
        routes.forEach(route => {
            if (route) {
                if (route.path !== '*')
                    finalRoutes.push(route);
                if (route.routes)
                    getRoutes(route.routes, finalRoutes);
            }
        });
    } else if (routes.path !== '*')
        finalRoutes.push(routes);
    return finalRoutes;
};

const getRoutesByLevel = (routes, level) => getRoutes(routes).filter(route => route.level === level);

const groupRoutesByPath = routes => {
    const finalRoutes = [];
    getRoutes(routes).forEach(route => {
        if (route.level === 1)
            finalRoutes[route.path] = [];

        if (route.level === 2)
            finalRoutes[`/${route.path.split('/')[1]}`].push(route);
    });
    return finalRoutes;
};

const routesInit = routes => ({
    type: ROUTES_INIT,
    payload: {
        config: routes,
        navbar: getRoutesByLevel(routes, 1),
        sidebar: groupRoutesByPath(routes)
    }
});

const documentTitle = docTitle => {
    let title;
    switch (process.env.NODE_ENV) {
        case 'test': {
            title = `[Test] ${docTitle}`;
            break;
        }
        case 'development': {
            title = `[Dev] ${docTitle}`;
            break;
        }
        default:
            break;
    }
    if (typeof document !== 'undefined')
        document.title = title;
};

const windowResize = data => dispatch => {
    dispatch({
        type: WINDOW_RESIZE,
        payload: data
    });
};

const sidebarToggle = () => dispatch => {
    dispatch({type: SIDEBAR_TOGGLE});
};

const sidebarSetVisible = isVisible => dispatch => {
    dispatch({
        type: SIDEBAR_SET_VISIBLE,
        payload: isVisible
    });
};

const resetErrors = () => dispatch => {
    dispatch({type: RESET_ERRORS});
};

const toastr = (type, content, time, onClick = null) => dispatch => {
    dispatch({
        type: TOASTR,
        payload: {type, content, time, onClick}
    });
};

const resetToastr = () => dispatch => {
    dispatch({
        type: TOASTR,
        payload: {type: '', content: '', time: 0, onClick: null}
    });
};

const redirect = (path, callback) => dispatch => {
    callback(path);
    dispatch({type: REDIRECT_RESET});
};

export default {
    routesInit,
    windowResize,
    documentTitle,
    sidebarToggle,
    sidebarSetVisible,
    resetErrors,
    toastr,
    resetToastr,
    redirect
};
