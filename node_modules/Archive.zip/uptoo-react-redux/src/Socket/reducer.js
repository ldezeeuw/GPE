import {SOCKET_ON_MESSAGE} from './constants';

const initialState = {
    type: null,
    data: {}
};

export default function reduce(state = initialState, {type, payload}) {
    switch (type) {
        case SOCKET_ON_MESSAGE:
            return {type: payload.type, data: payload.data};

        default:
            return state;
    }
}
