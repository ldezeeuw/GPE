export const SOCKET_ON_MESSAGE = 'SOCKET_ON_MESSAGE';

export default {SOCKET_ON_MESSAGE};
