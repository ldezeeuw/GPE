import {SOCKET_ON_MESSAGE} from './constants';

const onMessage = (type, data) => dispatch => {
    dispatch({
        type: SOCKET_ON_MESSAGE,
        payload: {
            data,
            type
        }
    });
};

export default {onMessage};
