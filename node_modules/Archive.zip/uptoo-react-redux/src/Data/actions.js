import querystring from 'querystring';
import * as Utils from 'uptoo-react-utils';
import DataConsts from './constants';

const DataActionsInstance = class DataActions extends DataConsts {
    constructor(UtilsClass) {
        super();

        this.Requester = UtilsClass.Requester;
    }

    init = ({data, url, filter, select, populate, sort, itemsPerPage}) => ({
        loading: false,
        error: false,
        data: data || {},
        params: {
            url,
            filter,
            select,
            populate,
            sort
        },
        pagination: {
            currentIndex: 1,
            itemsPerPage: itemsPerPage || 25,
            totalPages: 0,
            totalItems: 0
        }
    });

    setParams = (oldParams, nextParams) => ({
        data: nextParams.data || oldParams.data,
        params: {
            ...oldParams.params,
            ...nextParams
        },
        pagination: {
            ...oldParams.pagination,
            ...nextParams
        }
    });

    get = ({params, pagination}, id = null) => dispatch => {
        const configuration = {params: {...params}};

        if (id) {
            dispatch({type: this.ITEM_LOADING});
            if (id !== true)
                configuration.params.url = `${params.url}/${id}`;
        } else {
            configuration.pagination = pagination;
            dispatch({type: this.ITEMS_LOADING});
            dispatch({
                type: this.ITEMS_CONFIG,
                payload: {params, pagination}
            });
        }

        this.Requester.get(configuration).then(resp => {
            if (id) dispatch({type: this.ITEM_DATA, payload: resp.data});
            else dispatch({type: this.ITEMS_DATA, payload: resp});
        }, err => {
            if (id) dispatch({type: this.ITEM_ERROR, payload: err.message});
            else dispatch({type: this.ITEMS_ERROR, payload: err.message});
        });
    };

    post = (url, object) => dispatch => {
        dispatch({type: this.CREATE_LOADING});

        this.Requester.post({url, object}).then(resp => {
            dispatch({
                type: this.CREATE_DATA,
                payload: resp.data
            });
        }, err => {
            dispatch({
                type: this.CREATE_ERROR,
                payload: err.message
            });
        });
    };

    put = (path, object, overwrite = true) => dispatch => {
        dispatch({type: this.EDIT_LOADING});

        let url = path;

        if (object._id)
            url = `${path}/${object._id}`;

        this.Requester.put({url, object}).then(resp => {
            dispatch({
                type: this.EDIT_DATA,
                payload: resp.data
            });
            if (overwrite) {
                dispatch({
                    type: this.ITEM_DATA,
                    payload: object
                });
            }
        }, err => {
            dispatch({
                type: this.EDIT_ERROR,
                payload: err.message
            });
        });
    };

    delete = (originUrl, params) => dispatch => {
        let url = originUrl;
        dispatch({type: this.DELETE_LOADING});

        if (typeof params === 'string')
            url = `${url}/${params}`;
        else if (typeof params === 'object') {
            if (params._id)
                url = `${url}/${params._id}`;
            else
                url = `${url}?${querystring.stringify(params)}`;
        }

        this.Requester.delete({url}).then(resp => {
            dispatch({
                type: this.DELETE_DATA,
                payload: resp
            });
        }, err => {
            dispatch({
                type: this.DELETE_ERROR,
                payload: err.message
            });
        });
    };

    itemsEdit = item => dispatch => {
        dispatch({
            type: this.ITEMS_EDIT,
            payload: item
        });
    };

    itemsDelete = id => dispatch => {
        dispatch({
            type: this.ITEMS_DELETE,
            payload: id
        });
    };

    itemsReset = () => dispatch => {
        dispatch({type: this.ITEMS_RESET});
    };
};

let instance = null;

function getInstance() {
    /**
     * Singelton (Une seul instance de classe)
     *
     * Instanciated with the default storage manager
     */
    if (!instance)
        instance = new DataActionsInstance(Utils);
    return instance;
}

export default {
    Instance: DataActionsInstance,
    init: getInstance().init,
    setParams: getInstance().setParams,
    items: {
        edit: getInstance().itemsEdit,
        delete: getInstance().itemsDelete,
        reset: getInstance().itemsReset
    },
    get: getInstance().get,
    post: getInstance().post,
    put: getInstance().put,
    delete: getInstance().delete
};
