import TplConst from './../Template/constants';
import Const from './constants';

const {RESET_ERRORS} = new TplConst();

const initialState = {
    items: {
        loading: false,
        error: null,
        data: [],
        params: {
            url: '',
            filter: null,
            select: null,
            populate: null,
            sort: null
        },
        pagination: {
            currentIndex: 1,
            itemsPerPage: 25,
            totalPages: 0,
            totalItems: 0
        }
    },
    item: {
        loading: false,
        error: null,
        data: {},
        params: {
            url: '',
            select: null,
            populate: null
        }
    },
    create: {
        loading: false,
        error: null,
        data: {}
    },
    edit: {
        loading: false,
        error: null,
        data: {}
    },
    delete: {
        loading: false,
        error: null,
        data: {}
    }
};

export default function reduce(state = initialState, {type, payload}) {
    switch (type) {
        case RESET_ERRORS:
            return {
                ...state,
                items: {...state.items, error: null},
                item: {...state.item, error: null},
                create: {...state.create, error: null},
                edit: {...state.edit, error: null},
                delete: {...state.delete, error: null}
            };

        case Const.ITEMS_LOADING:
            return {
                ...state,
                items: {
                    ...state.items,
                    loading: true,
                    error: null
                }
            };

        case Const.ITEMS_ERROR:
            return {
                ...state,
                items: {
                    ...state.items,
                    loading: false,
                    error: payload,
                    data: []
                }
            };

        case Const.ITEMS_DATA:
            return {
                ...state,
                items: {
                    ...state.items,
                    loading: false,
                    data: payload.data,
                    pagination: {
                        currentIndex: payload.currentIndex,
                        itemsPerPage: payload.itemsPerPage,
                        totalItems: payload.totalItems,
                        totalPages: payload.totalPages
                    }
                }
            };

        case Const.ITEMS_RESET:
            return {
                ...state,
                items: initialState.items
            };

        case Const.ITEMS_CONFIG:
            return {
                ...state,
                items: {
                    ...state.items,
                    params: payload.params,
                    pagination: payload.pagination
                }
            };

        case Const.ITEMS_DELETE:
            return {
                ...state,
                items: {
                    ...state.items,
                    data: state.items.data.filter(item => item._id !== payload)
                }
            };

        case Const.ITEMS_EDIT:
            return {
                ...state,
                items: {
                    ...state.items,
                    data: state.items.data.map(item => (item._id === payload._id ? {...item, ...payload} : item))
                }
            };

        case Const.ITEM_LOADING:
            return {
                ...state,
                item: {
                    loading: true,
                    error: null,
                    data: {}
                }
            };

        case Const.ITEM_ERROR:
            return {
                ...state,
                item: {
                    loading: false,
                    error: payload,
                    data: {}
                }
            };

        case Const.ITEM_DATA:
            return {
                ...state,
                item: {
                    loading: false,
                    error: null,
                    data: payload
                }
            };

        case Const.ITEM_RESET:
            return {
                ...state,
                item: initialState.item
            };

        case Const.CREATE_LOADING:
            return {
                ...state,
                create: {
                    loading: true,
                    error: null,
                    data: {}
                }
            };

        case Const.CREATE_ERROR:
            return {
                ...state,
                create: {
                    loading: false,
                    error: payload,
                    data: {}
                }
            };

        case Const.CREATE_DATA:
            return {
                ...state,
                create: {
                    loading: false,
                    error: null,
                    data: payload
                }
            };

        case Const.CREATE_RESET:
            return {
                ...state,
                create: initialState.create
            };

        case Const.EDIT_LOADING:
            return {
                ...state,
                edit: {
                    loading: true,
                    error: null,
                    data: {}
                }
            };

        case Const.EDIT_ERROR:
            return {
                ...state,
                edit: {
                    loading: false,
                    error: payload,
                    data: {}
                }
            };

        case Const.EDIT_DATA:
            return {
                ...state,
                edit: {
                    loading: false,
                    error: null,
                    data: payload
                }
            };

        case Const.EDIT_RESET:
            return {
                ...state,
                edit: initialState.edit
            };

        case Const.DELETE_LOADING:
            return {
                ...state,
                delete: {
                    loading: true,
                    error: null,
                    data: {}
                }
            };

        case Const.DELETE_ERROR:
            return {
                ...state,
                delete: {
                    loading: false,
                    error: payload,
                    data: {}
                }
            };

        case Const.DELETE_DATA:
            return {
                ...state,
                delete: {
                    loading: false,
                    error: null,
                    data: payload
                }
            };

        case Const.DELETE_RESET:
            return {
                ...state,
                edit: initialState.edit
            };

        default:
            return state;
    }
}
