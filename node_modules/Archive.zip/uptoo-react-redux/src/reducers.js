import Auth from './Auth/reducer';
import Data from './Data/reducer';
import Socket from './Socket/reducer';
import Template from './Template/reducer';

const reducers = {
    Auth,
    Data,
    Socket,
    Template,
};

export default reducers;
