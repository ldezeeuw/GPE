import reducers from './../src/reducers';
import AuthC from './../src/Auth/constants';
import DataC from './../src/Data/constants';
import AuthAction from './../src/Auth/actions';
import AuthReducer from './../src/Auth/reducer';
import DataAction from './../src/Data/actions';
import DataReducer from './../src/Data/reducer';
import SocketAction from './../src/Socket/actions';
import TemplateC from './../src/Template/constants';
import SocketReducer from './../src/Socket/reducer';
import SocketConsts from './../src/Socket/constants';
import TemplateAction from './../src/Template/actions';
import TemplateReducer from './../src/Template/reducer';


const AuthConsts = new AuthC();
const DataConsts = new DataC();
const TemplateConsts = new TemplateC();

export const Auth = {
    reducer: AuthReducer,
    ...AuthConsts,
    ...AuthAction
};

export const Data = {
    reducer: DataReducer,
    ...DataConsts,
    ...DataAction
};

export const Socket = {
    reducer: SocketReducer,
    ...SocketConsts,
    ...SocketAction
};

export const Template = {
    reducer: TemplateReducer,
    ...TemplateConsts,
    ...TemplateAction
};

export const Reducers = reducers;
