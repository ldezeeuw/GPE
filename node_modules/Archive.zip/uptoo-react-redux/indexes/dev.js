/* eslint-disable */
import React from 'react';
import {render} from 'react-dom';
import {Reducers} from './build';

import AuthAction from './../src/Auth/actions';
import AuthReducer from './../src/Auth/reducer';
import DataAction from './../src/Data/actions';
import DataReducer from './../src/Data/reducer';
import SocketAction from './../src/Socket/actions';
import SocketReducer from './../src/Socket/reducer';
import TemplateAction from './../src/Template/actions';
import TemplateReducer from './../src/Template/reducer';
import reducers from './../src/reducers';

import SocketConsts from './../src/Socket/constants';

import AuthC from './../src/Auth/constants';
import DataC from './../src/Data/constants';
import TemplateC from './../src/Template/constants';

const AuthConsts = new AuthC();
const DataConsts = new DataC();
const TemplateConsts = new TemplateC();

console.log('ICICI', {
    reducer: AuthReducer,
    ...AuthConsts,
    ...AuthAction
});

// export const Data = {
//     reducer: DataReducer,
//     ...DataConsts,
//     ...DataAction
// };

// export const Socket = {
//     reducer: SocketReducer,
//     ...SocketConsts,
//     ...SocketAction
// };

// export const Template = {
//     reducer: TemplateReducer,
//     ...TemplateConsts,
//     ...TemplateAction
// };



const appRoot = document.getElementById('root');

rend();

function rend() {
    render(
        <div>
            HOT FIX PAGE
        </div>
        ,appRoot
    );
};