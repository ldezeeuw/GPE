/* eslint import/no-extraneous-dependencies: off */
const webpack = require('webpack');
const path = require('path');
const {BundleAnalyzerPlugin} = require('webpack-bundle-analyzer');

const plugins = [
    new webpack.ProvidePlugin({'uptoo-react-utils': 'uptoo-react-utils'}),
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"production"',
        'process.env.PLATFORM_ENV': '"web"'
    }),
    new webpack.optimize.UglifyJsPlugin({
        compress: {
            warnings: false,
            screw_ie8: true,
            dead_code: true,
            unused: true
        },
        output: {comments: false},
    })
];

if (process.argv.indexOf('debug') > -1)
    plugins.push(new BundleAnalyzerPlugin());

module.exports = {
    entry: {
        'uptoo-react-redux': path.join(__dirname, './../indexes/build.js'),
        reducers: path.join(__dirname, './../src/reducers')
    },
    output: {
        path: path.join(__dirname, '/../dist'),
        filename: '[name].js',
        library: 'uptoo-react-redux',
        libraryTarget: 'umd',
        umdNamedDefine: true
    },
    externals: {'uptoo-react-utils': 'uptoo-react-utils'},
    resolve: {extensions: ['*', '.js']},
    module: {
        loaders: [{
            test: /\.js?$/,
            loader: 'babel-loader',
            include: path.join(__dirname, './../src'),
            exclude: /node_modules/,
            query: {
                presets: ['env'],
                plugins: ['transform-object-rest-spread']
            }
        }],
    },
    plugins
};
