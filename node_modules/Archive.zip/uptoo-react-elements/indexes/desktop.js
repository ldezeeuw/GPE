/* eslint-disable */
import link                 from './../src/desktop/Link/';
import socket               from './../src/desktop/Socket/';
import win                  from './../src/desktop/Window/';
import subRoute             from './../src/desktop/SubRoute/';
import permission           from './../src/desktop/Permission/';

export const Link           = link;
export const Socket         = socket;
export const Window         = win;
export const SubRoute       = subRoute;
export const Permission     = permission;
