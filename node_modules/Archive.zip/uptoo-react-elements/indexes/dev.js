/* eslint-disable */
import React                from 'react';
import {render}            from 'react-dom';

// const {whyDidYouUpdate} = require('why-did-you-update');
// whyDidYouUpdate(React);

import AppMenu from './../src/desktop/AppMenu/'

const appRoot = document.getElementById('root');

rend();

function rend(display = true) {
    render(
        <div id="app-content">
            HOT FIX

            <div style={{marginLeft: '500px'}}><AppMenu active="klimbr1" /></div>
        </div>
        ,appRoot
    );
}
