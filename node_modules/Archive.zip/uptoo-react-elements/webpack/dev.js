/* eslint-disable */
const path = require('path');
// const webpack = require('webpack');
const BellOnBundlerErrorPlugin = require('bell-on-bundler-error-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const buildDirectory = './dist/';
require("babel-polyfill");

module.exports = {
    externals: {
        'react/lib/ExecutionEnvironment': true,
        'react/lib/ReactContext': true
    },
    entry: ["babel-polyfill", './indexes/dev.js'],
    devtool: 'cheap-module-eval-source-map',
    devServer: {
        hot: true,
        inline: true,
        port: 7700,
        historyApiFallback: true
    },
    resolve: {
        extensions: ['*', '.js', '.jsx']
    },
    output: {
        path: path.resolve(buildDirectory),
        filename: 'app.js',
        publicPath: 'http://localhost:7700/dist'
    },
    module: {
        loaders: [{
            test: /\.jsx?$/,
            exclude: /node_modules/,
            loader: 'babel-loader',
            query: {
                presets: ['airbnb', 'es2015', 'stage-0']
            }
        }, {
            test: /\.js$/,
            exclude: /node_modules/,
            loader: 'eslint-loader',
            query: {
                presets: ['airbnb', 'es2015', 'stage-0']
            }
        }, {
            test: /\.less$/,
            loader: 'style-loader!css-loader!autoprefixer-loader!less-loader'
        }, {
            test: /\.(gif|jpe?g|png)$/,
            loader: 'url-loader?mimetype=image/png'
        }]
    },
    plugins: [
        new BellOnBundlerErrorPlugin(),
        new ExtractTextPlugin("style.css")
    ]
};