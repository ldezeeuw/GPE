/* eslint-disable */
const webpack                   = require('webpack');
const UglifyJsPlugin            = webpack.optimize.UglifyJsPlugin;
const path                      = require('path');
const env                       = require('yargs').argv.env;
var BundleAnalyzerPlugin        = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const ExtractTextPlugin         = require('extract-text-webpack-plugin');

let plugins = [
    new webpack.ProvidePlugin({
        react: "react"
    }),
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"production"',
        'process.env.PLATFORM_ENV': '"web"',
        'process.env.BABEL_ENV': '"production"'
    }),
    new webpack.optimize.UglifyJsPlugin({
        compress: {
            warnings: false,
            screw_ie8: true,
            dead_code: true,
            unused: true
        },
        output: {
            comments: false,
        },
        exclude: [/\.min\.js$/gi]
    })
];

if (process.argv.indexOf('debug') > -1)
    plugins.push(new BundleAnalyzerPlugin());

module.exports = {
    entry: {
        'mobile/uptoo-react-elements': __dirname + './../indexes/mobile.js',
        'desktop/uptoo-react-elements': __dirname + './../indexes/desktop.js'
    },
    output: {
        path: path.resolve(__dirname, './../dist'),
        filename: '[name].js',
        library: 'uptoo-react-elements',
        libraryTarget: 'umd',
        umdNamedDefine: true
    },
    externals: {
        react: 'react',
        'react-dom': {
            root: 'ReactDOM',
            commonjs2: 'react-dom',
            commonjs: 'react-dom',
            amd: 'react-dom'
        }
    },
    resolve: {extensions: ['*', '.js', '.jsx', '.json']},
    module: {
        loaders: [{
            test: /\.js?$/,
            loader: 'babel-loader',
            exclude: /node_modules/,
            query: {presets: ['airbnb', 'es2015', 'stage-0']}
        }, {
            test: /\.less$/,
            loader: 'style-loader!css-loader!autoprefixer-loader!less-loader'
        }],
    },
    plugins
};
