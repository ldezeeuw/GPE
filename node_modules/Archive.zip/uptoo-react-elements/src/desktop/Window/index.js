import {Component} from 'react';
import PropTypes from 'prop-types';

export default class Window extends Component {
    static propTypes = {action: PropTypes.func.isRequired};

    componentDidMount() {
        this.updateDimensions();
        window.addEventListener('resize', this.updateDimensions);
    }

    shouldComponentUpdate() {
        return false;
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.updateDimensions);
    }

    updateDimensions = () => {
        let device = 'desktop';

        if (window.innerWidth < 768)
            device = 'mobile';
        if (window.innerWidth >= 768 && window.innerWidth <= 1024)
            device = 'tablet';
        if (typeof device !== 'undefined' && typeof window.innerWidth !== 'undefined')
            this.props.action({device, width: window.innerWidth});
    }

    render() {
        return null;
    }
}
