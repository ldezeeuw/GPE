/* eslint no-unused-vars: "off" */
import React, {PureComponent} from 'react';
import {connect} from 'react-redux';
import {renderRoutes} from 'react-router-config';
import PropTypes from 'prop-types';

class SubRoute extends PureComponent {
    static propTypes = {route: PropTypes.object.isRequired};

    render() {
        return renderRoutes(this.props.route.routes);
    }
}

const mapStateToProps = () => ({});
const mapDispatchToProps = () => ({});

export default connect(mapStateToProps, mapDispatchToProps)(SubRoute);
