import React, {Component} from 'react';
import PropTypes from 'prop-types';

export default class Permissions extends Component {
    static propTypes = {
        except: props => {
            if (typeof props.only === 'undefined' && typeof props.except === 'undefined')
                return new Error('You have to specify at least one prop \'except or only\'');
            else if (typeof props.except !== 'object' && typeof props.except !== 'string' && typeof props.except !== 'undefined')
                return new Error('The props except must be typed as an Array or a String');
            return null;
        },
        only: props => {
            if (typeof props.only === 'undefined' && typeof props.except === 'undefined')
                return new Error('You have to specify at least one prop \'except or only\'');
            else if (typeof props.only !== 'object' && typeof props.only !== 'string' && typeof props.only !== 'undefined')
                return new Error('The props only must be typed as an Array or a String');
            return null;
        },
        permissions: props => {
            if (typeof props.only !== 'object' && typeof props.only !== 'string')
                return new Error('The props permissions must be typed as an Array or a String');
            return null;
        },
        children: PropTypes.oneOfType([
            PropTypes.object,
            PropTypes.element,
            PropTypes.string
        ]).isRequired
    };

    static defaultProps = {
        except: [],
        only: [],
        permissions: []
    };

    constructor(props) {
        super(props);

        this.state = {
            only: null,
            except: null
        };

        const only = Array.isArray(this.props.only) ? this.props.only : [this.props.only];
        const except = Array.isArray(this.props.except) ? this.props.except : [this.props.except];
        const permissions = Array.isArray(this.props.permissions) ? this.props.permissions : [this.props.permissions];

        only.forEach(item => {
            this.state.only = false;
            if (permissions.indexOf(item) !== -1)
                this.state.only = true;
        });

        except.forEach(item => {
            this.state.except = true;
            if (permissions.indexOf(item) !== -1)
                this.state.except = false;
        });
    }

    render() {
        return (
            this.state.only ?
                this.props.children :
                this.state.except ?
                    this.props.children :
                    null
        );
    }
}
