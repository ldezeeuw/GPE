import React, {Component} from 'react';
import PropTypes from 'prop-types';
import ReactLink from 'react-router-dom/Link';

export default class Link extends Component {
    static propTypes = {
        className: PropTypes.string,
        style: PropTypes.object,
        to: PropTypes.string.isRequired,
        children: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.element
        ]).isRequired,
        target: PropTypes.string
    };

    static defaultProps = {
        className: '',
        style: {},
        target: null
    };

    render() {
        return (
            this.props.to.substring(0, 4) === 'http' ?
                <a
                  {...this.props.target}
                  style={this.props.style}
                  className={this.props.className}
                  href={this.props.to}
                >
                    {this.props.children}
                </a>
            :
                <ReactLink
                  {...this.props.target}
                  style={this.props.style}
                  to={this.props.to}
                  className={this.props.className}
                >
                    {this.props.children}
                </ReactLink>
        );
    }
}
