/* eslint func-names: "off" */
import {PureComponent} from 'react';
import * as io from 'socket.io-client';
import PropTypes from 'prop-types';

export default class Socket extends PureComponent {
    static propTypes = {
        url: PropTypes.string.isRequired,
        token: PropTypes.string.isRequired,
        onMessage: PropTypes.func.isRequired
    };

    constructor(props) {
        super(props);

        this.state = {};
        this.socket = io.connect(this.props.url, {query: `token=${this.props.token}`});

        const onevent = this.socket.onevent;

        this.socket.onevent = function (initialPacket) {
            const packet = initialPacket;
            const args = packet.data || [];
            packet.data = ['*'].concat(args);
            onevent.call(this, packet);
        };

        this.socket.on('*', (e, data) => {
            if (typeof e !== 'undefined' && typeof data !== 'undefined')
                this.props.onMessage(e, data);
        });
    }

    componentWillUnmount() {
        this.socket.close();
    }

    render() {
        return null;
    }
}
