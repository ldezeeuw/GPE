import React, {Component} from 'react';
import PropTypes from 'prop-types';
import AppsMenuLogo from './../../assets/AppsMenuIcon.png';
import './index.less';

export default class index extends Component {
    static propTypes = {active: PropTypes.string.isRequired};

    state = {
        style: {
            backgroundImage: `url(${AppsMenuLogo})`,
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat'
        },
        open: false
    }

    shouldComponentUpdate(nextProps, nextState) {
        return JSON.stringify(nextState) !== JSON.stringify(this.state) || this.props.active !== nextProps.active;
    }

    render() {
        return (
            <div id="AppMenuItem">
                <div
                  id="menuLogo"
                  role="button"
                  tabIndex={0}
                  onKeyDown={() => this.setState({open: !this.state.open})}
                  onClick={() => this.setState({open: !this.state.open})}
                  style={this.state.style}
                />
                {this.state.open ?
                    <div className="container">
                        <a
                          className={this.props.active === 'klimbr1' ? 'item active' : 'item'}
                          href={this.props.active === 'klimbr1' ? '#' : 'https://apps.uptoo.fr/'}
                        >
                            KLIMBR 1
                        </a>
                        <hr style={{margin: '0px'}} />
                        <a
                          className={this.props.active === 'klimbr2' ? 'item active' : 'item'}
                          href={this.props.active === 'klimbr2' ? '#' : 'https://klimbr.uptoo.fr/'}
                        >
                            KLIMBR 2
                        </a>
                        <hr style={{margin: '0px'}} />
                        <a
                          className={this.props.active === 'production' ? 'item active' : 'item'}
                          href={this.props.active === 'production' ? '#' : 'https://production.uptoo.fr/'}
                        >
                            PRODUCTION
                        </a>
                        <hr style={{margin: '0px'}} />
                        <a
                          className={this.props.active === 'accounting' ? 'item active' : 'item'}
                          href={this.props.active === 'accounting' ? '#' : 'https://accounting.uptoo.fr/'}
                        >
                            COMPTABILITE
                        </a>
                    </div>
                : null}
            </div>
        );
    }
}
