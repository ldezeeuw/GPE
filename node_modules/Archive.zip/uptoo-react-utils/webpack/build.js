const path = require('path');
const webpack = require('webpack');
const {BundleAnalyzerPlugin} = require('webpack-bundle-analyzer');

const plugins = [
    new webpack.ProvidePlugin({
        'react': 'react',
        'uptoo-react-elements': 'uptoo-react-elements',
        // 'uptoo-react-redux': 'uptoo-react-redux'
    }),
    new webpack.NoEmitOnErrorsPlugin(),
    new webpack.DefinePlugin({
        'process.env.NODE_ENV': '"production"',
        'process.env.PLATFORM_ENV': '"web"'
    }),
    new webpack.optimize.UglifyJsPlugin({
        compress: {
            warnings: false,
            screw_ie8: true,
            dead_code: true,
            unused: true
        },
        output: {comments: false},
    })
];

if (process.argv.indexOf('debug') > -1)
    plugins.push(new BundleAnalyzerPlugin());

module.exports = {
    entry: {
        'Api': path.join(__dirname, './../src/Api'),
        'CRUD': path.join(__dirname, './../src/CRUD'),
        'Config': path.join(__dirname, './../src/Config'),
        'Storage': path.join(__dirname, './../src/Storage'),
        'Cookies': path.join(__dirname, './../src/Cookies'),
        'Requester': path.join(__dirname, './../src/Requester'),
        'ShallowEquals': path.join(__dirname, './../src/ShallowEquals'),
        'MobileStorage': path.join(__dirname, './../src/MobileStorage'),
        'uptoo-react-utils': path.join(__dirname, './../indexes/build.js')
    },
    output: {
        path: path.join(__dirname, '/../dist'),
        filename: '[name].js',
        library: 'uptoo-react-utils',
        libraryTarget: 'umd',
        umdNamedDefine: true
    },
    externals: {
        'react': 'react',
        'uptoo-react-elements': 'uptoo-react-elements',
        // 'uptoo-react-redux': 'uptoo-react-redux'
    },
    resolve: {extensions: ['*', '.js']},
    module: {
        loaders: [{
            test: /\.js?$/,
            loader: 'babel-loader',
            include: path.join(__dirname, './../src'),
            exclude: /node_modules/,
            query: {
                presets: ['env'],
                plugins: ['transform-object-rest-spread']
            }
        }],
    },
    plugins
};
