const path = require('path');
const webpack = require('webpack');
const BellOnBundlerErrorPlugin = require('bell-on-bundler-error-plugin');

const buildDirectory = './dist/';

module.exports = {
    externals: {
        'react/lib/ExecutionEnvironment': true,
        'react/lib/ReactContext': true,
    },
    entry: './indexes/dev.js',
    devtool: 'cheap-module-eval-source-map',
    devServer: {
        hot: true,
        inline: true,
        port: 7700,
        historyApiFallback: true,
    },
    resolve: {
        extensions: ['*', '.js', '.jsx'],
    },
    output: {
        path: path.resolve(buildDirectory),
        filename: 'app.js',
        publicPath: 'http://localhost:7700/dist',
    },
    module: {
        loaders: [{
            test: /\.js?$/,
            exclude: /bower_components/,
            loader: 'babel-loader',
            query: {
                presets: ['airbnb', 'es2015', 'stage-0'],
            },
        },{
            test: /\.less$/,
            loader: 'style-loader!css-loader!autoprefixer-loader!less-loader'
        }],
    },
    plugins: [
        new BellOnBundlerErrorPlugin(),
        new webpack.DefinePlugin({
            'process.env.NODE_ENV': '"developpement"',
            'process.env.PLATFORM_ENV': '"web"'
        }),
    ]
};