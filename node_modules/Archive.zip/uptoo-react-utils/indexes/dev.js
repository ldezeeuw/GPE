/* eslint-disable */
import React    from 'react';
import {render} from 'react-dom';
import Api from './../src/Api'

const appRoot = document.getElementById('root');

rend();

function rend() {
    render(
        <div>
            HOT FIX PAGE
        </div>
        ,appRoot
    );
}