# React utils library '1.0.0'

This project is developed and maintained by the UPTOO developer team.

### Prerequisites

[React](https://reactjs.org/) >= "^15.6.2"
[Semantic ui](https://react.semantic-ui.com) >= "^0.73.0".

## Getting Started
  
```
npm install --save git+ssh://github.com/uptoo/react-utils-uptoo.git

```

Available commands
```
npm run test            // Start tests
npm run build           // Build library (in dist folder)
npm run build -- debug  // Build library and output what's bundled
npm run dev             // Dev server to fix or enhance components ('indexes/HotFix.js')
npm run doc             // Run a server to generate an HTML page based on your READMEs
```

Available modules

```
import {
    AppConvigToModule,  // = {get(), set()}
    CRUD,               // = {get(), post(), put(), delete()}
    Cookies,            // = {setCookie(), deleteCookie(), getCookie()}
    Requester,          // = {get(), post(), put(), delete()}
    Storage             // = {get(), set(), delete()}
} from 'react-utils-uptoo';
```

## Built With

* [React](https://reactjs.org/) - The web library used "^15.6.2"
* [Semantic ui react](https://react.semantic-ui.com/introduction) - Ui framework "^0.73.0"

## Author

* **Dezeeuw Louis** - *Initial work*

## License

* This project is private
[![N|Solid](http://www.ffc-carrosserie.org/sites/default/files/Logo%20Uptoo.jpg)](https://nodesource.com/products/nsolid)