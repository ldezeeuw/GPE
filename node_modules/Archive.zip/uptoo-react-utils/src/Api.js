import querystring from 'querystring';
import Cookies from './Cookies';
import Requester from './Requester'
// const _that = new WeakMap();

const ApiClass = class Api {
    constructor(StorageManager)
    {
        this.Requester = new Requester.Instance(StorageManager);
        // Pour la V2 ajouter les params au constructeur et les enlever des fonctions (this, objectName...)
        
        //  | |
        //  v v
        
        // _that.set(this, that);
    }

    reset = {
        deleted: undefined,
        updated: undefined,
        created: undefined
    };

    encodeGetUrl = ({params: {url, select, filter, populate, sort, query}, pagination: {itemsPerPage = null, currentIndex = null} = {}}) => {
        let encodedUrl = url;

        if (select || filter || populate || sort || currentIndex || itemsPerPage)
            encodedUrl = `${url}?q`;
        if (select)
            encodedUrl += this.encode('select', select);
        if (filter)
            encodedUrl += this.encode('filter', filter);
        if (populate)
            encodedUrl += this.encode('populate', populate);
        if (sort)
            encodedUrl += this.encode('sort', sort);
        if (currentIndex)
            encodedUrl += this.encode('currentIndex', currentIndex);
        if (itemsPerPage)
            encodedUrl += this.encode('itemsPerPage', itemsPerPage);
        if (query)
            encodedUrl += query;

        return encodedUrl;
    };

    init = ({data, url, filter, select, populate, sort, itemsPerPage}) => ({
        loading: false,
        error: false,
        data: data || {},
        params: {
            url,
            filter,
            select,
            populate,
            sort
        },
        pagination: {
            currentIndex: 1,
            itemsPerPage: itemsPerPage || 25,
            totalPages: 0,
            totalItems: 0
        }
    });

    setParams = (oldParams, nextParams) => ({
        data: nextParams.data || oldParams.data,
        params: {
            ...oldParams.params,
            ...nextParams
        },
        pagination: {
            ...oldParams.pagination,
            ...nextParams
        }
    });

    encode = (field, value) => `&${field}=${encodeURIComponent(JSON.stringify(value))}`;

    get = (that, objectName, id = null, nextParams = {}, callback = null) => {
        const { data, params, pagination } = this.setParams(that.state[objectName], nextParams)
        const configuration = { params: { ...params } }

        that.setState({
            [objectName]: {
                ...this.reset,
                params,
                data,
                pagination,
                loading: true,
                error: false
            }
        })

        if (id) configuration.params.url = `${params.url}/${id}`;
        else configuration.pagination = pagination

        Requester
        .get(this.encodeGetUrl(configuration))
        .then(resp => {
            let { data, ...pagination } = resp
            if (callback) callback(data)

            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    data,
                    pagination
                }
            })
        }, err => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    error: err.message,
                    data
                }
            });
        });
    };

    post = (that, objectName, object, overwrite = true) => {
        const url = that.state[objectName].params.url
        if (!url) throw new Error('Api.post need params.url on state object')
        
        that.setState({
            [objectName]: {
                ...that.state[objectName],
                ...this.reset,
                loading: true,
                error: false
            }
        });

        Requester
        .post(url, object)
        .then(resp => {
            let data = that.state[objectName].data

            if (overwrite) {
                data = { ...data, ...resp.data, ...object } // resp avant ce qu'on envoie pour garder les doc populated
            }

            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    created: resp.data._id,
                    data
                }
            });

        }, err => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    error: err.message
                }
            });
        });
    };

    put = (that, objectName, object, overwrite = true) => {
        that.setState({
            [objectName]: {
                ...that.state[objectName],
                ...this.reset,
                loading: true,
                error: false
            }
        });

        let url = object._id ? `${that.state[objectName].params.url}/${object._id}` : that.state[objectName].params.url

        Requester
        .put(url, object)
        .then(resp => {

            let data = that.state[objectName].data

            if (overwrite) {
                data = { ...data, ...resp.data, ...object } // resp avant ce qu'on envoie pour garder les doc populated
            }

            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    updated: true,
                    data
                }
            });

        }, err => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    error: err.message
                }
            });
        });
    };

    delete = (that, objectName, params) => {
        that.setState({
            [objectName]: {
                ...that.state[objectName],
                ...this.reset,
                loading: true,
                error: false,
            }
        });

        let url = that.state[objectName].params.url

        if (typeof params == 'string')
            url = `${url}/${params}`;
        else if (typeof params == 'object') {
            if (params._id)
                url = `${url}/${params._id}`;
            else
                url = `${url}?${querystring.stringify(params)}`;
        }

        Requester
        .delete(url)
        .then(resp => {
            let data = { ...that.state[objectName].data, ...resp.data }

            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    deleted: true,
                    data
                }
            });
        }, err => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    loading: false,
                    error: err.message
                }
            });
        });
    };

    autocomplete = (that, objectName, filter, callback = null) => {
        let url = `${that.state[objectName].params.url}?`
        
        url = url + Object.keys(filter).map(function(k) {
            return encodeURIComponent(k) + "=" + encodeURIComponent(JSON.stringify(filter[k]));
        }).join('&')

        Requester.get(url).then(resp => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    data: resp.data 
                }
            })

            if (callback && resp.data.length > 0) {
                callback(resp.data[0])
            } else if (callback) {
                callback({})
            }
        }, err => {
            that.setState({
                [objectName]: {
                    ...that.state[objectName],
                    data: []
                }
            })
        });
    };
}

let instance = null;

function getInstance() {
    /**
     * Singelton (Une seul instance de classe)
     * 
     * Instanciated with the default storage manager
     */
    if (!instance)
        instance = new ApiClass(Cookies);
    return instance;
}


export default {
    Instance: ApiClass,
    init: getInstance().init,
    setParams: getInstance().setParams,
    get: getInstance().get,
    post: getInstance().post,
    put: getInstance().put,
    delete: getInstance().delete,
    autocomplete: getInstance().autocomplete,
};
