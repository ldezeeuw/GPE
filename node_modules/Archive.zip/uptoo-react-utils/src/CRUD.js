// import Requester from './Requester';

// const encode = (field, value) => `&${field}=${encodeURIComponent(JSON.stringify(value))}`;

// function get({params: {url, select, filter, populate, sort, query}, pagination: {itemsPerPage = null, currentIndex = null} = {}}) {
//     let encodedUrl = url;
//     if (select || filter || populate || sort || currentIndex || itemsPerPage)
//         encodedUrl = `${url}?q`;

//     if (select)
//         encodedUrl += encode('select', select);
//     if (filter)
//         encodedUrl += encode('filter', filter);
//     if (populate)
//         encodedUrl += encode('populate', populate);
//     if (sort)
//         encodedUrl += encode('sort', sort);
//     if (currentIndex)
//         encodedUrl += encode('currentIndex', currentIndex);
//     if (itemsPerPage)
//         encodedUrl += encode('itemsPerPage', itemsPerPage);
//     /**
//      * For MBJ search we need to add more params to the query
//      * we also need pagination params
//      */
//     if (query)
//         encodedUrl += query;

//     return Requester.get(encodedUrl);
// }

// const del = ({url}) => Requester.delete(url);
// const put = ({url, object}) => Requester.put(url, object);
// const post = ({url, object}) => Requester.post(url, object);

// export default {
//     get,
//     post,
//     put,
//     delete: del
// };
