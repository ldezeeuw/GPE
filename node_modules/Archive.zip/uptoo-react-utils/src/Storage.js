const Storage = {
    set(name, value) {
        return window.localStorage.setItem(name, typeof value === 'string' ? value : JSON.stringify(value));
    },
    get(name) {
        return JSON.parse(window.localStorage.getItem(name));
    },
    delete(name) {
        return window.localStorage.removeItem(name);
    }
};

export default Storage;
