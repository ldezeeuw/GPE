// /* eslint vars-on-top: "off" */
// /* eslint no-var: "off" */
// if (process.env.PLATFORM_ENV !== 'web')
//     var {AsyncStorage} = require('react-native').AsyncStorage;

// const MobileStorage = {
//     set(key, value) {
//         AsyncStorage.setItem(key, value);
//     },

//     async get(key) {
//         const value = await AsyncStorage.getItem(key);
//         return value;
//     },

//     delete(key) {
//         AsyncStorage.removeItem(key);
//     }
// };

// export default MobileStorage;
